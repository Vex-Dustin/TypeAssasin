package page;

import app.Monster;
import app.Skill;
import java.util.ArrayList;
import utilities.IO;

public class Input {
    String username;
    int score, life;
    ArrayList<Skill> skillList = new ArrayList<>();
    ArrayList<Monster> monsterList = new ArrayList<>();
    
    public Input() {
        readPlayerInfo();
        readSkillList();
        while (true) {
            System.out.print("Input Combo (use ', ' in between skill): ");
            String comboString = IO.scanner.nextLine();
            
            String[] combos = comboString.split(", ");
            boolean bisa = true;
            int damage = 0;
            for (String combo: combos) {
                boolean ada = false;
                for (Skill skill: skillList) {
                    if (skill.getNama().equals(combo)) {
                        ada = true;
                        damage += skill.getDamage();
                        break;
                    }
                }
                if (!ada) {
                    bisa = false;
                }
            }
            if (!bisa) {
                System.out.println("Invalid Combo!");
                continue;
            }
            
            monsterList.clear();
            readMonsterList();
            if (monsterList.get(0).getHp() == damage) {
                System.out.println(monsterList.get(0).getName() + " has been slain!");
                score += 100;
                monsterList.remove(0);
            } else {
                life--;
            }
            savePlayerInfo();
            saveMonster();
        }
    }
    
    private void readPlayerInfo() {
        ArrayList<String> datas = IO.readFile("playerInfo.txt");
        for (String line: datas) {
            String[] data = line.split("#");
            username = data[0];
            life = Integer.parseInt(data[1]);
            score = Integer.parseInt(data[2]);
        }
    }
    
    private void readSkillList() {
        ArrayList<String> datas = IO.readFile("skillList.txt");
        for (String line: datas) {
            String[] data = line.split("#");
            Skill skill = new Skill(data[0], Integer.parseInt(data[1]));
            skillList.add(skill);
        }
    }
    private void readMonsterList() {
        ArrayList<String> datas = IO.readFile("monsterList.txt");
        for (String line: datas) {
            String[] data = line.split("#");
            Monster mons = new Monster(data[0], Integer.parseInt(data[1]), Integer.parseInt(data[2]));
            monsterList.add(mons);
        }
    }
    
    private void savePlayerInfo() {
        ArrayList<String> data = new ArrayList<>();
        data.add(String.format("%s#%d#%d", this.username, this.life, this.score));
        IO.writeFile("playerInfo.txt", data);
    }
    
    private void saveMonster() {
        ArrayList<String> data = new ArrayList<>();
        for (Monster mons: monsterList) {
            String line = String.format("%s#%d#%d", mons.getName(), mons.getHp(), mons.getTime());
            data.add(line);
        }
        IO.writeFile("monsterList.txt", data);
    }
}
