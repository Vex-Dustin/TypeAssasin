package page;

import app.Monster;
import app.Skill;
import java.util.ArrayList;
import utilities.IO;

public class Output {
    String username;
    int score, life;
    
    ArrayList<Monster> monsterList = new ArrayList<>();
    ArrayList<Skill> skillList = new ArrayList<>();
    
    public Output() {
        System.out.print("Enter your username: ");
        username = IO.scanner.nextLine();
        this.score = 0;
        this.life = 3;
        
        for (int i = 0; i < 5; i++) {
            boolean bisa = true;
            Skill newSkill = new Skill();
            for (Skill skill: skillList) {
                if (skill.getNama().equals(newSkill.getNama())) {
                    bisa = false;
                }
            }
            if (bisa) {
                skillList.add(newSkill);
            } else {
                i--;
            }
        }
        
        monsterList.clear();
        saveMonster();
        
        saveSkill();
        savePlayerInfo();
        
        
        loop();
    }
    
    private void loop() {
        readMonsterList();
        readPlayerInfo();
        if (monsterList.isEmpty()) {
            generateNewMonster();
        } else {
            monsterList.get(0).setTime(monsterList.get(0).getTime() - 1);
        }
        if (monsterList.get(0).getTime() == 0) {
            life--;
            monsterList.remove(0);
            saveMonster();
            savePlayerInfo();
        }
        if (life <= 0) {
            System.out.println("Game Over!");
            return;
        }
        
        displayInfo();
        
        long sTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - sTime < 1000) {
        }
        loop();
    }
    
    private void displayInfo() {
        IO.clear();
        // Name
        System.out.println("Username: " + this.username);
        // Nyawa
        System.out.println("Life: " + this.life);
        // Score
        System.out.println("Score: " + this.score);
        // MonsterList
        System.out.println("+----+------------------+----+------+");
        System.out.println("| No | Monster Name     | HP | Time |");
        System.out.println("+----+------------------+----+------+");
        int counter = 1;
        for (Monster mons: monsterList) {
            String row = String.format("| %-2d | %-16s | %-2d | %-4d |", counter, mons.getName(), mons.getHp(), mons.getTime());
            System.out.println(row);
            counter++;
        }
        System.out.println("+----+------------------+----+------+");
        System.out.println("");
        
        // SkillList
        // No Skill Name Damage
        System.out.println("+----+------------+--------+");
        System.out.println("| No | Skill Name | Damage |");
        System.out.println("+----+------------+--------+");
        counter = 1;
        for (Skill skill: skillList) {
            String row = String.format("| %-2d | %-10s | %-6d |", counter, skill.getNama(), skill.getDamage());
            System.out.println(row);
            counter++;
        }
        System.out.println("+----+------------+--------+");
    }
    
    private void generateNewMonster() {
        int hp = skillList.get(IO.rand.nextInt(skillList.size())).getDamage();
        for (Skill skill: skillList) {
            hp += skill.getDamage() * IO.rand.nextInt(3);
        }
        Monster mons = new Monster(hp);
        monsterList.add(mons);
    }
    
    private void saveSkill() {
        ArrayList<String> data = new ArrayList<>();
        for (Skill skill: skillList) {
            String line = String.format("%s#%d", skill.getNama(), skill.getDamage());
            data.add(line);
        }
        IO.writeFile("skillList.txt", data);
    }
    
    private void saveMonster() {
        ArrayList<String> data = new ArrayList<>();
        for (Monster mons: monsterList) {
            String line = String.format("%s#%d#%d", mons.getName(), mons.getHp(), mons.getTime());
            data.add(line);
        }
        IO.writeFile("monsterList.txt", data);
    }
    
    private void savePlayerInfo() {
        ArrayList<String> data = new ArrayList<>();
        data.add(String.format("%s#%d#%d", this.username, this.life, this.score));
        IO.writeFile("playerInfo.txt", data);
    }
    
    private void readMonsterList() {
        ArrayList<String> datas = IO.readFile("monsterList.txt");
        for (String line: datas) {
            String[] data = line.split("#");
            Monster mons = new Monster(data[0], Integer.parseInt(data[1]), Integer.parseInt(data[2]));
            monsterList.add(mons);
        }
    }
    
    private void readPlayerInfo() {
        ArrayList<String> datas = IO.readFile("playerInfo.txt");
        for (String line: datas) {
            String[] data = line.split("#");
            username = data[0];
            life = Integer.parseInt(data[1]);
            score = Integer.parseInt(data[2]);
        }
    }
}
