package app;

import java.util.ArrayList;
import java.util.Arrays;
import utilities.IO;

public class Skill {
    private ArrayList<String> nameList = new ArrayList<>(Arrays.asList("Lightning", "Healing", "Rage", "Poison", "Earthquake", "Jump", "Freeze", "Haste"));
    private String nama;
    private int damage;
    
    public Skill() {
        this.nama = nameList.get(IO.rand.nextInt(nameList.size()));
        this.damage = IO.rand.nextInt(10) + 5;
    }
    
    public Skill(String nama, int damage) {
        this.nama = nama;
        this.damage = damage;
    }

    public String getNama() {
        return nama;
    }

    public int getDamage() {
        return damage;
    }
    
}
