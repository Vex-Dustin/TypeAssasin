package main;

import app.Monster;
import java.util.ArrayList;
import page.Input;
import page.Output;
import utilities.IO;

public class TypeAssassin {
    
    public TypeAssassin() {
        String input;
        do {
            IO.clear();
            printMenu();
            input = IO.scanner.nextLine();
            if (input.equals("1")) {
                new Input();
            } else if (input.equals("2")) {
                new Output();
            } else if (input.equals("3")) {

            } else if (input.equals("4")) {

            }
        } while (!input.equals("5"));
        
        // random nama, hp, waktu
//        Monster mons1 = new Monster();
//        mons1.getHp();
    }
    
    public static void main(String[] args) {
        new TypeAssassin();
    }
    
    public void printMenu() {
        System.out.println("Welcome to Type Assassin!");
        System.out.println("1. Input Mode");
        System.out.println("2. Output Mode");
        System.out.println("3. Rules");
        System.out.println("4. Leaderboard");
        System.out.println("5. Close");
        System.out.print("Input: ");
    }
    
}
